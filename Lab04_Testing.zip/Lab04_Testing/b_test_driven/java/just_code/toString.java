/*public String toString() {
  if (next == null)
  return data;
  else
  return data + ", " + next.toString();
}
*/